#!/usr/bin/python3
from distutils.core import setup
setup(
        name='qtgui',
        version='0.0.1',
        author='Huang tao',
        author_email='huangtao.jh@gmail.com',
        platforms='any',
        description='python3 pyqt wraper',
        long_description='python3 pyqt wraper',
        packages=['qtgui'],
        license='GPL',
        requires=['pyqt3_pyqt5']
        )
